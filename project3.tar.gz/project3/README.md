# CSCI442-MemoryManagement

Team Name: willCodeForBeer

Team Members:
Christian Wert
Arnold Clarke
Travis Boyd
Jack Nelson
__________________________________________________

Time Spent on Intermediate I: We spent 1.5 hours working on this together.
Time Spent on Intermediate II: We spent 5 hours each working on this part.
Time Spent on Final Submission: We spent about 2 hours working on this together.
__________________________________________________

We don't really have any unusual or interesting features. We just implemented
everything in the assignment document and all of the provided tests pass.
__________________________________________________

The hardest part of the assignment was debugging. We wrote most of our code and
almost all of our tests didn't pass. After hours of debugging, we figured out that
we had a small error in add_hole that caused all of our problems.
__________________________________________________

We have no additional comments regarding this assignment.
